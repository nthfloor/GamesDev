//Map editor program for Fly-DragonFly 2D scroller game
//Nathan Floor
//FLRNAT001

public class Runner {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MainFrame screen = new MainFrame(800,600);
		
		screen.setVisible(true);
	}

}
